from random import *
class Pergunta:
	def __init__(self):
		self.level = [
		['Seu gato está Erguido e com os olhos esbugalhados?','parado'],
		['Seu gato está sentado e agitando a cauda?','agitado'],
		['Seu gato está arranhando os móveis?','esfregando'],
		['Seu gato está se esfregando nos móveis?','esfregando'],		
		]

	def texto(self):
		string = self.level[0]
		del self.level[0]
		return string
