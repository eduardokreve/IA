# SistemaEspecialista
pequeno programa em python utilizando técnicas dos sistemas especialistas para diagnosticar o "Bem estar do seu Pet"
